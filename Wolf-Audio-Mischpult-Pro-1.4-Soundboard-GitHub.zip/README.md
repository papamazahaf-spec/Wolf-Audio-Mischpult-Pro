# Wolf Audio Mischpult Pro 1.4 – Soundboard

Android-App mit Mischpult-Oberfläche und sechs Kanalzügen und einem Soundboard: Spotify, YouTube, YouTube Music, TikTok, MIC und MASTER. Projekt zum **Bauen** einer Debug-APK. **Keine vorgefertigte APK enthalten**.

## Bedienung

1. **Spotify / YouTube / YouTube Music / TikTok**: APP ÖFFNEN startet die jeweilige App, falls sie installiert ist. Unter **APP-WAHL** kannst du nach Freigabe aktive Media-Sessions / zuletzt benutzte Apps sehen und als Musik-/Live-Kanal zuordnen.
2. **MASTER**: Nur dieser vertikale Fader ändert die Medienlautstärke von Android. Die anderen Balken zeigen denselben Gesamtwert, sie sind **keine getrennten Lautstärkeregler**. MUTE stellt die *gesamte* Medienlautstärke stumm und wieder her. Es gibt zusätzlich einen waagerechten Medienregler.
3. **PLAY/PAUSE**: Mit optionalem Benachrichtigungs-/Medienzugriff steuert die App aktive Medien-Sessions, **sofern** die Drittanbieter-App externe Steuerung zulässt. Es gibt keinen automatischen Zugriff auf alle Hintergrundprozesse.
4. **Bluetooth-Geräte / Mikrofon**: Mit »GERÄTE PRÜFEN« Bluetooth-Berechtigung erlauben. Die App zeigt:
   - aktive Bluetooth-Audioausgänge
   - aktive Bluetooth-Mikrofoneingänge, die Android meldet
   - gekoppelte Geräte und ihre verbundenen Bluetooth-Audioprofile: HFP-Freisprechprofil (Mikrofon *wahrscheinlich*), A2DP-Musikprofil (kein Mikrofon-Nachweis) oder ungeklärter Status
   - eine Auswahl der von Android erkannten Mikrofonquellen für den lokalen Test
5. **MIKROFON TESTEN**: Audioaufnahmeberechtigung erlauben und den Pegel beobachten. Angezeigt wird der **tatsächlich von Android an den Testrecorder geroutete Eingang**, sofern das System ihn meldet. Aufnahme wird nur zur Pegelmessung verwendet, **nicht gespeichert oder gesendet**. Der Test endet automatisch, wenn die App verlassen wird.
6. **SOUND ASSISTANT**, **TON & VIBRATION** und **BT-GERÄTE** öffnen Samsung-/Android-Einstellungen.

### Warum nicht einfach Spotify zur Box und TikTok zum Headset schalten?

Android stellt gewöhnlichen Apps keine allgemeine Schnittstelle bereit, um den Ton **anderer Apps** dauerhaft auf zwei beliebige Bluetooth-Geräte zu verteilen. Auch welches Mikrofon **TikTok selbst** verwendet, kann diese App nicht erzwingen. **Mikrofon erkannt** bedeutet nur: Android zeigt einen Eingang, das Freisprechprofil ist aktiv oder der Test liefert Signal – keine Zusage, dass TikTok den gleichen Eingang benutzt.

Auf Samsung kann »**Separater App-Ton**« ausgewählte Apps auf ein separates Audiogerät legen (unter Einstellungen → Töne und Vibration → Separater App-Ton). Laut Samsung ist der Ausgang entweder **Telefon** oder **Bluetooth-Gerät**, und muss vom Hauptausgang verschieden sein. Eine Garantie für parallele Ausgaben auf **zwei unterschiedliche Bluetooth-Geräte** ergibt sich daraus nicht. Quelle: https://www.samsung.com/de/support/mobile-devices/separater-ton-und-toneinstellungen/

Sound Assistant kann – wenn auf dem jeweiligen Gerät verfügbar – App-Lautstärken über seine eigene Bedienoberfläche anpassen. Das Wolf-Mischpult darf diese Regler nicht stellvertretend manipulieren.

## GitHub APK-Build

1. Die Inhalte **dieses Projektordners** (inklusive des versteckten `.github`-Ordners) in die **Repository-Wurzel** auf GitHub hochladen. Nicht nur `app/` hochladen.
2. GitHub → **Actions** → **Wolf Audio Mischpult Pro Soundboard APK** → **Run workflow**.
3. Nach erfolgreichem Job: **Artifacts** → `Wolf-Audio-Soundboard-Pro-APK` herunterladen.
4. Die heruntergeladene ZIP öffnen und `app-debug.apk` auf dem Android-Handy installieren.

**Build:** Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, compileSdk/targetSdk 35, minSdk 29; keine externen App-Abhängigkeiten. GitHub Actions installiert das Android SDK 35 automatisch.

**Berechtigungen:** Bluetooth zur Audio-Geräteerkennung; Mikrofon für den lokalen Pegeltest; optional Benachrichtigungslistener zur MediaSession-Steuerung; optional Nutzungsdatenzugriff für zuletzt verwendete Apps. Die App fordert keine Internetberechtigung an.

**Teststatus:** Quelldateien und ZIP-Struktur können lokal geprüft werden; hier steht kein Android SDK für einen echten Build oder ein gekoppeltes Samsung-Gerät für Bluetooth-/TikTok-Tests bereit. Ein erfolgreicher GitHub-Build muss am Gerät geprüft werden.


## NEU in 1.4: Soundboard mit echten Audiodateien

- Sechs FX-Pads: **Applaus, Buh-Rufe, Lachen, Trompete, Trommelwirbel, Buzzer**.
- Jede Taste spielt unmittelbar einen kurzen **mitgelieferten, selbst synthetisch erzeugten Beispielklang** (keine Original-Menschenaufnahme) über den aktuellen Android-Medienausgang ab. Alle Klänge liegen offline unter `app/src/main/res/raw/*.wav`.
- Eigener Sound: pro Taste **EIGENER SOUND** antippen und eigene **MP3/WAV/OGG/M4A/AAC** (maximal 8 MB, Format muss durch Android decodierbar sein) importieren. Die Datei bleibt lokal im Speicher der App. Über **STANDARD** wieder den eingebauten Sound einstellen.
- Eigener **FX-Lautstärkeregler** mit 0–100 %, Wiederholung in der Vordergrund-App, sofortiger **STOPP**. Es spielt jeweils **ein FX-Sound** gleichzeitig, statt beliebig viele übereinander.
- Keine Internetrechte nötig. Mikrofontest und App-Erkennung aus 1.3 bleiben erhalten.
- **WICHTIG:** Die FX-Pads erzeugen Ton in dieser App, sie leiten ihn **nicht automatisch als Mikrofon an TikTok Live**. Wenn das Soundboard in den Hintergrund geht, können keine weiteren Tasten gedrückt werden. Für Tonübertragung zu TikTok wären eine tatsächlich unterstützte Misch-/Capture-Lösung oder externe Hardware nötig.

Die Beispielklänge sind **synthetische Demos**, keine heruntergeladenen Audiodateien. Für realistische Applaus-/Lach-/Buh-/Trompetensounds importiere eigene legale Aufnahmen.
