package de.wolf.btaudioduo;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioDeviceCallback;
import android.view.MotionEvent;
import android.widget.HorizontalScrollView;
import java.util.Set;
import java.util.HashSet;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Android-Audiozentrale ohne Root: System-Medienpegel und eigener Mikrofontest.
 * Routing/Level anderer Apps (Spotify, TikTok usw.) kann Android Dritt-Apps nicht
 * zuverlässig erlauben. Die entsprechenden Schritte passieren in Samsung SoundAssistant
 * bzw. "Separater App-Ton". Kein heimliches Audio-Capturing oder Fake-Routing.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH = 100;
    private static final int REQUEST_MICROPHONE = 101;
    private static final int REQUEST_EFFECT_FILE = 102;
    private static final int BG = Color.rgb(10, 17, 30);
    private static final int CARD = Color.rgb(22, 35, 53);
    private static final int TEXT = Color.WHITE;
    private static final int SUB = Color.rgb(182, 202, 219);
    private static final int CYAN = Color.rgb(48, 213, 245);
    private static final int YELLOW = Color.rgb(255, 200, 76);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final String[] FX_KEYS = {"applaus", "buh", "lachen", "trompete", "trommelwirbel", "buzzer"};
    private static final String[] FX_NAMES = {"👏 APPLAUS", "👎 BUH-RUFE", "😂 LACHEN", "🎺 TROMPETE", "🥁 TROMMEL", "🚨 BUZZER"};
    private static final int[] FX_RESOURCES = {R.raw.applaus, R.raw.buh, R.raw.lachen, R.raw.trompete, R.raw.trommelwirbel, R.raw.buzzer};
    private MediaPlayer effectPlayer;
    private int effectVolume = 80;
    private CheckBox loopEffect;
    private TextView effectStatus;
    private String pendingEffectId;
    private final Map<String, TextView> effectLabels = new LinkedHashMap<>();
    private AudioManager audioManager;
    private LinearLayout root;
    private TextView deviceState, micState, volumeLabel, micDetectionSummary;
    private final List<LevelTrack> musicTracks = new ArrayList<>();
    private LevelTrack micTrack;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothProfile headsetProfile, musicProfile;
    private boolean profileRequestsStarted = false;
    private int previousMediaVolume = 5;
    private AudioDeviceCallback audioCallback;
    private final BluetoothProfile.ServiceListener profileListener = new BluetoothProfile.ServiceListener() {
        @Override public void onServiceConnected(int type, BluetoothProfile proxy) {
            if (type == BluetoothProfile.HEADSET) headsetProfile = proxy;
            if (type == BluetoothProfile.A2DP) musicProfile = proxy;
            runOnUiThread(() -> { if (!isFinishing()) refreshDevices(); });
        }
        @Override public void onServiceDisconnected(int type) {
            if (type == BluetoothProfile.HEADSET) headsetProfile = null;
            if (type == BluetoothProfile.A2DP) musicProfile = null;
            runOnUiThread(() -> { if (!isFinishing()) refreshDevices(); });
        }
    };
    private TextView selectedMusicLabel, selectedLiveLabel, appListStatus;
    private LinearLayout appListContainer;
    private String selectedMusic = "com.spotify.music";
    private String selectedLive = "com.zhiliaoapp.musically";
    private SeekBar musicSlider;
    private ProgressBar microphoneMeter;
    private Button micButton;
    private Spinner inputSelector;
    private final List<AudioDeviceInfo> inputDevices = new ArrayList<>();
    private volatile boolean recording = false;
    private AudioRecord recorder;
    private Thread recorderThread;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager != null ? bluetoothManager.getAdapter() : null;
        previousMediaVolume = Math.max(1, audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        selectedMusic = getPreferences(MODE_PRIVATE).getString("channel_music", selectedMusic);
        selectedLive = getPreferences(MODE_PRIVATE).getString("channel_live", selectedLive);
        effectVolume = getPreferences(MODE_PRIVATE).getInt("fx_volume", 80);
        createScreen();
        audioCallback = new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] added) { refreshDevices(); }
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) { refreshDevices(); }
        };
        audioManager.registerAudioDeviceCallback(audioCallback, handler);
        refreshDevices();
        refreshAppList();
    }

    private void createScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setPadding(dp(16), dp(22), dp(16), dp(24));
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                root.setPadding(dp(16), dp(22) + bars.top, dp(16), dp(24) + bars.bottom);
                return insets;
            });
            scroll.requestApplyInsets();
        }

        TextView title = text("WOLF  |  AUDIO MIXER", 26, TEXT, true);
        root.addView(title);
        label(root, "Wolf Audio Mischpult Pro 1.4 · Soundboard · Android", 14, SUB);
        space(root, 12);
        TextView info = text("Sechs Kanalzüge, Soundboard, App-Auswahl, Masterfader und Bluetooth-Mikrofonerkennung. Das Ton-Routing erfolgt über Samsung.", 14, SUB, false);
        root.addView(info);
        space(root, 18);
        createMixerBoard();
        space(root, 13);
        createSoundboard();
        space(root, 13);

        LinearLayout musicCard = card("KANAL 1   ▸   MUSIK  /  BOX", YELLOW);
        selectedMusicLabel = text("MUSIK: Spotify", 15, TEXT, true);
        musicCard.addView(selectedMusicLabel);
        label(musicCard, "Musik-App über Samsung »Separater App-Ton« mit der Bluetooth-Box verbinden.", 13, SUB);
        rowButtons(musicCard, "MUSIK-APP ÖFFNEN", () -> openApp(selectedMusic), "TON EINSTELLEN", this::openSoundSettings);
        space(musicCard, 8);
        volumeLabel = text("System-Medienlautstärke", 14, TEXT, true);
        musicCard.addView(volumeLabel);
        musicSlider = new SeekBar(this);
        musicSlider.setMax(Math.max(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)));
        musicSlider.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        musicSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(YELLOW));
        musicSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(YELLOW));
        musicCard.addView(musicSlider);
        musicSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean user) {
                if (!user) return;
                try { audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0); }
                catch (Exception e) { toast("Medienlautstärke lässt sich hier nicht ändern."); }
                updateMusicLevel();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        label(musicCard, "Hinweis: Dieser Regler ändert den gemeinsamen Medienpegel, nicht nur Spotify.", 12, SUB);
        space(root, 12);

        LinearLayout liveCard = card("KANAL 2   ▸   TIKTOK  /  HEADSET", CYAN);
        selectedLiveLabel = text("LIVE: TikTok", 15, TEXT, true);
        liveCard.addView(selectedLiveLabel);
        label(liveCard, "TikTok hören + über Headset sprechen", 15, TEXT);
        label(liveCard, "Den Bluetooth-Kopfhörer als Hauptausgabe wählen. Ob TikTok dessen Mikrofon benutzt, entscheidet TikTok/Android.", 13, SUB);
        rowButtons(liveCard, "LIVE-APP ÖFFNEN", () -> openApp(selectedLive), "BLUETOOTH", this::openBluetoothSettings);
        space(liveCard, 10);
        label(liveCard, "Mikrofonquelle für lokalen Funktionstest", 13, TEXT);
        inputSelector = new Spinner(this);
        inputSelector.setBackgroundColor(Color.rgb(35, 53, 74));
        liveCard.addView(inputSelector);
        space(liveCard, 8);
        micState = text("Mikrofontest aus", 13, SUB, false);
        liveCard.addView(micState);
        microphoneMeter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        microphoneMeter.setMax(100);
        microphoneMeter.setProgress(0);
        microphoneMeter.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        LinearLayout.LayoutParams meterParams = new LinearLayout.LayoutParams(-1, dp(11));
        meterParams.topMargin = dp(7);
        meterParams.bottomMargin = dp(9);
        liveCard.addView(microphoneMeter, meterParams);
        micButton = button("MIKROFON TESTEN", CYAN, this::toggleMic);
        liveCard.addView(micButton);
        label(liveCard, "Nur der Test innerhalb dieser App. Keine Weiterleitung des Mikrofons zu TikTok. Vor einem TikTok-Live wieder stoppen.", 12, SUB);
        space(root, 12);

        LinearLayout appsCard = card("APP-WAHL   ▸   LAUFENDE & LETZTE APPS", YELLOW);
        label(appsCard, "Hier siehst du aktive Medien-Apps und zuletzt geöffnete Apps. Wähle pro App MUSIK oder LIVE. Die Auswahl speichert nur deine Mischpult-Belegung – sie schaltet nicht heimlich den Bluetooth-Ausgang um.", 13, SUB);
        rowButtons(appsCard, "MEDIENZUGRIFF", () -> launchSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
                "APP-NUTZUNG", () -> launchSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        label(appsCard, "Medienzugriff: optional für laufende Musik und Play/Pause. Android gewährt dabei auch Benachrichtigungszugriff. App-Nutzung: optional für zuletzt benutzte Apps. Keine Datenübertragung.", 12, SUB);
        Button refreshApps = button("APP-LISTE AKTUALISIEREN", YELLOW, this::refreshAppList);
        appsCard.addView(refreshApps);
        space(appsCard, 9);
        appListStatus = text("Apps werden geladen …", 13, SUB, false);
        appsCard.addView(appListStatus);
        appListContainer = new LinearLayout(this);
        appListContainer.setOrientation(LinearLayout.VERTICAL);
        appsCard.addView(appListContainer);
        space(root, 12);

        LinearLayout settingsCard = card("MIXER-EINSTELLUNGEN", CYAN);
        label(settingsCard, "Samsung kann Lautstärken je App und getrennte App-Ausgabe über Sound Assistant steuern.", 13, SUB);
        micDetectionSummary = text("Mikrofonerkennung wird geprüft …", 14, TEXT, true);
        settingsCard.addView(micDetectionSummary);
        label(settingsCard, "Ein BT-Musikanschluss (A2DP) beweist NICHT, dass ein Gerät kein Mikrofon hat. Ein verbundenes Freisprechprofil (HFP) zeigt Mikrofonfähigkeit an; ein wirklicher Funktionstest ist sicherer.", 12, SUB);
        rowButtons(settingsCard, "SOUND ASSISTANT", this::openSoundAssistant, "TON & VIBRATION", this::openSoundSettings);
        rowButtons(settingsCard, "BT-GERÄTE", this::openBluetoothSettings, "GERÄTE PRÜFEN", this::requestRefresh);
        space(settingsCard, 6);
        deviceState = text("Bluetooth-Geräte werden geladen …", 13, SUB, false);
        settingsCard.addView(deviceState);
        space(root, 14);
        TextView warning = text("TECHNISCHE GRENZE: Eine normale Android-App kann die Audioausgabe anderer Apps nicht frei auf zwei unterschiedliche Bluetooth-Geräte verteilen und TikTok kein Headset-Mikrofon aufzwingen. Zwei parallel verbundene Geräte bedeuten nicht zwei frei wählbare getrennte Audiowege.", 12, SUB, false);
        root.addView(warning);
        updateMusicLevel();
    }

    /** FX samples are generated locally and packaged under res/raw; user can override each pad. */
    private void createSoundboard() {
        LinearLayout panel = card("SOUND BOARD  ▸  EFFEKTE", Color.rgb(240, 116, 217));
        label(panel, "Auf eine Taste tippen, um einen Effekt abzuspielen. »Eigener Sound« lädt MP3, WAV, OGG oder M4A für diese Taste.", 13, SUB);
        for (int i = 0; i < FX_KEYS.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < Math.min(i + 2, FX_KEYS.length); j++) {
                final String id = FX_KEYS[j];
                final int resource = FX_RESOURCES[j];
                LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setPadding(dp(5), dp(7), dp(5), dp(7));
                LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, -2, 1);
                row.addView(tile, tileLp);
                int color = (j % 2 == 0) ? YELLOW : CYAN;
                Button soundButton = button(FX_NAMES[j], color, () -> playEffect(id, resource));
                soundButton.setTextSize(13);
                tile.addView(soundButton, new LinearLayout.LayoutParams(-1, dp(57)));
                Button change = button("EIGENER SOUND", Color.rgb(159, 179, 209), () -> importEffect(id));
                change.setTextSize(10);
                LinearLayout.LayoutParams changeLp = new LinearLayout.LayoutParams(-1, dp(37));
                changeLp.topMargin = dp(6);
                tile.addView(change, changeLp);
                TextView status = text(customEffectFile(id) == null ? "Beispielklang" : "Eigene Datei", 11, SUB, false);
                status.setGravity(Gravity.CENTER);
                tile.addView(status);
                effectLabels.put(id, status);
                Button restore = button("STANDARD", Color.rgb(109, 128, 149), () -> restoreEffect(id));
                restore.setTextSize(10);
                LinearLayout.LayoutParams restoreLp = new LinearLayout.LayoutParams(-1, dp(31));
                restoreLp.topMargin = dp(4);
                tile.addView(restore, restoreLp);
            }
            panel.addView(row);
        }
        space(panel, 10);
        TextView volume = text("Soundboard-Lautstärke: " + effectVolume + "%", 14, TEXT, true);
        panel.addView(volume);
        SeekBar slider = new SeekBar(this);
        slider.setMax(100);
        slider.setProgress(effectVolume);
        panel.addView(slider);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seek, int progress, boolean fromUser) {
                effectVolume = progress;
                volume.setText("Soundboard-Lautstärke: " + progress + "%");
                if (effectPlayer != null) effectPlayer.setVolume(progress / 100f, progress / 100f);
                if (fromUser) getPreferences(MODE_PRIVATE).edit().putInt("fx_volume", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seek) {}
            @Override public void onStopTrackingTouch(SeekBar seek) {}
        });
        loopEffect = new CheckBox(this);
        loopEffect.setText("Effekt wiederholen (nur solange das Mischpult geöffnet ist)");
        loopEffect.setTextColor(TEXT);
        panel.addView(loopEffect);
        effectStatus = text("Soundboard bereit · keine Aufnahme oder Übertragung an TikTok", 12, SUB, false);
        panel.addView(effectStatus);
        Button stop = button("■  ALLE EFFEKTE STOPPEN", Color.rgb(244, 121, 143), this::stopEffect);
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, dp(47));
        stopLp.topMargin = dp(9);
        panel.addView(stop, stopLp);
        label(panel, "Die FX-Töne spielen über den aktuellen Android-Medienausgang. TikTok bekommt diesen Ton NICHT automatisch als Mikrofoneingang. Eigene App-Effekte sind separat vom System-Medienregler einstellbar.", 12, SUB);
    }

    private File customEffectFile(String id) {
        String filename = getPreferences(MODE_PRIVATE).getString("fx_file_" + id, null);
        if (filename == null) return null;
        File file = new File(new File(getFilesDir(), "fx"), filename);
        return file.isFile() ? file : null;
    }

    private void playEffect(String id, int resourceId) {
        stopEffect();
        MediaPlayer player = null;
        try {
            File userSound = customEffectFile(id);
            if (userSound != null) {
                player = new MediaPlayer();
                player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                player.setDataSource(userSound.getAbsolutePath());
                player.prepare();
            } else {
                player = MediaPlayer.create(this, resourceId);
            }
            if (player == null) throw new IOException("Audioplayer konnte nicht gestartet werden");
            player.setVolume(effectVolume / 100f, effectVolume / 100f);
            player.setLooping(loopEffect != null && loopEffect.isChecked());
            player.setOnCompletionListener(done -> {
                if (effectPlayer == done) {
                    effectPlayer = null;
                    if (effectStatus != null) effectStatus.setText("Effekt beendet · bereit");
                }
                done.release();
            });
            effectPlayer = player;
            effectStatus.setText("Läuft: " + id.toUpperCase(Locale.GERMAN));
            player.start();
        } catch (Exception e) {
            if (player != null) try { player.release(); } catch (Exception ignored) {}
            effectPlayer = null;
            effectStatus.setText("Sound konnte nicht abgespielt werden.");
            toast("Dateiformat eventuell nicht unterstützt: " + e.getClass().getSimpleName());
        }
    }

    private void stopEffect() {
        MediaPlayer old = effectPlayer;
        effectPlayer = null;
        if (old != null) {
            try { old.setOnCompletionListener(null); old.stop(); } catch (Exception ignored) {}
            try { old.release(); } catch (Exception ignored) {}
        }
        if (effectStatus != null) effectStatus.setText("Gestoppt · Soundboard bereit");
    }

    private void importEffect(String id) {
        pendingEffectId = id;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        try { startActivityForResult(intent, REQUEST_EFFECT_FILE); }
        catch (ActivityNotFoundException e) { toast("Kein Datei-Auswahldialog gefunden."); }
    }

    private void restoreEffect(String id) {
        stopEffect();
        File current = customEffectFile(id);
        if (current != null) current.delete();
        getPreferences(MODE_PRIVATE).edit().remove("fx_file_" + id).apply();
        TextView label = effectLabels.get(id);
        if (label != null) label.setText("Beispielklang");
        toast("Standardklang für " + id + " wiederhergestellt.");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_EFFECT_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final String id = pendingEffectId;
        final Uri uri = data.getData();
        if (id == null) return;
        effectStatus.setText("Audiodatei wird geladen …");
        new Thread(() -> {
            File temp = null;
            try {
                String displayName = "sound.wav";
                try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) displayName = cursor.getString(0);
                }
                if (displayName == null) displayName = "sound.wav";
                String name = displayName.toLowerCase(Locale.ROOT);
                String ext = name.endsWith(".mp3") ? ".mp3" : name.endsWith(".wav") ? ".wav" :
                    name.endsWith(".ogg") ? ".ogg" : name.endsWith(".m4a") ? ".m4a" :
                    name.endsWith(".aac") ? ".aac" : null;
                if (ext == null) throw new IOException("Nur MP3, WAV, OGG, M4A oder AAC auswählen");
                File dir = new File(getFilesDir(), "fx");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Interner Ordner nicht verfügbar");
                temp = new File(dir, id + "_upload.tmp");
                long bytes = 0;
                try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(temp)) {
                    if (in == null) throw new IOException("Datei nicht lesbar");
                    byte[] buffer = new byte[16 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        bytes += read;
                        if (bytes > 8L * 1024 * 1024) throw new IOException("Maximal 8 MB pro Effekt");
                        out.write(buffer, 0, read);
                    }
                }
                if (bytes == 0) throw new IOException("Datei ist leer");
                File finalFile = new File(dir, id + ext);
                if (finalFile.exists() && !finalFile.delete()) throw new IOException("Alte Datei kann nicht ersetzt werden");
                if (!temp.renameTo(finalFile)) throw new IOException("Datei konnte nicht gesichert werden");
                // Validate using the Android decoder before accepting the file.
                MediaPlayer probe = new MediaPlayer();
                try { probe.setDataSource(finalFile.getAbsolutePath()); probe.prepare(); }
                catch (Exception e) { finalFile.delete(); throw new IOException("Nicht abspielbares Audioformat", e); }
                finally { probe.release(); }
                handler.post(() -> {
                    stopEffect();
                    File previous = customEffectFile(id);
                    if (previous != null && !previous.equals(finalFile)) previous.delete();
                    getPreferences(MODE_PRIVATE).edit().putString("fx_file_" + id, finalFile.getName()).apply();
                    TextView label = effectLabels.get(id);
                    if (label != null) label.setText("Eigene Datei");
                    effectStatus.setText("Eigener Sound für " + id + " gespeichert.");
                });
            } catch (Exception e) {
                if (temp != null) temp.delete();
                final String message = e.getMessage() == null ? "Import fehlgeschlagen" : e.getMessage();
                handler.post(() -> { effectStatus.setText("Import fehlgeschlagen"); toast(message); });
            }
        }, "WolfFXImport").start();
    }

    private void updateMusicLevel() {
        if (volumeLabel == null) return;
        int now = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int max = Math.max(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        volumeLabel.setText(String.format(Locale.GERMAN, "Medienpegel: %d / %d (systemweit)", now, max));
        int percent = Math.round(now * 100f / max);
        for (LevelTrack fader : musicTracks) fader.setLevel(percent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (musicSlider != null) {
            musicSlider.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
            updateMusicLevel();
        }
        if (deviceState != null) refreshDevices();
        if (appListContainer != null) refreshAppList();
    }

    /** The OS doesn't disclose an exhaustive "running background apps" list. */
    private void refreshAppList() {
        if (appListContainer == null) return;
        appListContainer.removeAllViews();
        updateChosenLabels();
        LinkedHashMap<String, String> sources = new LinkedHashMap<>();
        LinkedHashMap<String, MediaController> activeControllers = new LinkedHashMap<>();

        boolean mediaAccess = hasMediaAccess();
        if (mediaAccess) {
            try {
                MediaSessionManager manager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
                ComponentName listener = new ComponentName(this, MediaAccessService.class);
                List<MediaController> sessions = manager.getActiveSessions(listener);
                for (MediaController controller : sessions) {
                    String id = controller.getPackageName();
                    if (id == null || id.equals(getPackageName())) continue;
                    PlaybackState state = controller.getPlaybackState();
                    boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
                    sources.put(id, playing ? "SPIELT JETZT" : "Mediensteuerung verfügbar");
                    activeControllers.put(id, controller);
                }
            } catch (SecurityException e) {
                appListStatus.setText("Kein Medienzugriff: unter Medienzugriff zuerst genehmigen.");
            } catch (Exception e) {
                appListStatus.setText("Medienliste momentan nicht verfügbar.");
            }
        }

        boolean usageAccess = hasUsageAccess();
        if (usageAccess) {
            try {
                UsageStatsManager usage = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
                long now = System.currentTimeMillis();
                long cutoff = now - 24L * 60 * 60 * 1000;
                List<UsageStats> stats = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cutoff, now);
                if (stats != null) {
                    // One package may appear in several daily buckets: keep its newest entry.
                    Map<String, Long> recent = new LinkedHashMap<>();
                    for (UsageStats s : stats) {
                        if (s.getLastTimeUsed() < cutoff || s.getPackageName().equals(getPackageName())) continue;
                        String id = s.getPackageName();
                        if (getPackageManager().getLaunchIntentForPackage(id) == null) continue;
                        recent.put(id, Math.max(s.getLastTimeUsed(), recent.containsKey(id) ? recent.get(id) : 0L));
                    }
                    List<Map.Entry<String, Long>> ordered = new ArrayList<>(recent.entrySet());
                    ordered.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
                    int added = 0;
                    for (Map.Entry<String, Long> entry : ordered) {
                        if (added >= 12) break;
                        if (!sources.containsKey(entry.getKey())) {
                            sources.put(entry.getKey(), "Zuletzt verwendet (nicht zwingend noch offen)");
                            added++;
                        }
                    }
                }
            } catch (Exception ignored) {
                // Usage data is optional. Known apps remain selectable.
            }
        }

        // Selectable installed favorites, even if Android grants neither special access.
        for (String id : Arrays.asList("com.spotify.music", "com.google.android.youtube",
                "com.google.android.apps.youtube.music", "com.android.chrome",
                "com.zhiliaoapp.musically", "com.ss.android.ugc.trill")) {
            if (!sources.containsKey(id) && getPackageManager().getLaunchIntentForPackage(id) != null)
                sources.put(id, "Installiert · auswählbar");
        }
        for (String id : Arrays.asList(selectedMusic, selectedLive)) {
            if (!sources.containsKey(id) && getPackageManager().getLaunchIntentForPackage(id) != null)
                sources.put(id, "Deine gespeicherte Auswahl");
        }
        appListStatus.setText((mediaAccess ? "Aktive Medien erkannt" : "Medienzugriff nicht aktiviert")
                + "  •  " + (usageAccess ? "Letzte Apps sichtbar" : "App-Nutzung nicht aktiviert")
                + "\nListe umfasst nicht zwangsläufig alle Hintergrundprozesse.");

        if (sources.isEmpty()) label(appListContainer, "Keine Apps gefunden. Installiere/öffne Spotify, YouTube oder TikTok, oder erteile optionalen Zugriff.", 13, SUB);
        for (Map.Entry<String, String> source : sources.entrySet())
            createAppRow(source.getKey(), source.getValue(), activeControllers.get(source.getKey()));
    }

    private void createAppRow(String id, String status, MediaController mediaController) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(12), dp(10), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(31, 47, 68));
        bg.setCornerRadius(dp(12));
        panel.setBackground(bg);
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, -2);
        panelParams.topMargin = dp(9);
        appListContainer.addView(panel, panelParams);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        try { icon.setImageDrawable(getPackageManager().getApplicationIcon(id)); }
        catch (PackageManager.NameNotFoundException ignored) { icon.setImageResource(android.R.drawable.sym_def_app_icon); }
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(36), dp(36));
        iconLp.rightMargin = dp(10);
        header.addView(icon, iconLp);
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(text(appName(id), 15, TEXT, true));
        names.addView(text(status, 12, SUB, false));
        header.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(header);
        if (mediaController != null) {
            MediaMetadata metadata = mediaController.getMetadata();
            CharSequence title = metadata != null ? metadata.getText(MediaMetadata.METADATA_KEY_TITLE) : null;
            if (title != null && title.length() != 0) label(panel, "Titel: " + title, 12, SUB);
        }
        rowButtons(panel, "MUSIK WÄHLEN", () -> chooseApp(id, true), "LIVE WÄHLEN", () -> chooseApp(id, false));
        if (mediaController != null) {
            rowButtons(panel, "APP ÖFFNEN", () -> openApp(id), "PLAY / PAUSE", () -> toggleMedia(mediaController));
        } else {
            Button open = button("APP ÖFFNEN", CYAN, () -> openApp(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42));
            lp.topMargin = dp(8);
            panel.addView(open, lp);
        }
    }

    private void chooseApp(String id, boolean music) {
        if (music) selectedMusic = id; else selectedLive = id;
        getPreferences(MODE_PRIVATE).edit().putString(music ? "channel_music" : "channel_live", id).apply();
        updateChosenLabels();
        toast(appName(id) + " als " + (music ? "Musik" : "Live") + " ausgewählt. Bluetooth-Zuweisung zusätzlich in Samsung einstellen.");
    }

    private void updateChosenLabels() {
        if (selectedMusicLabel != null) selectedMusicLabel.setText("MUSIK-AUSWAHL: " + appName(selectedMusic));
        if (selectedLiveLabel != null) selectedLiveLabel.setText("LIVE-AUSWAHL: " + appName(selectedLive));
    }

    private String appName(String packageId) {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(packageId, 0);
            return getPackageManager().getApplicationLabel(info).toString();
        } catch (PackageManager.NameNotFoundException ignored) {
            if (packageId.equals("com.spotify.music")) return "Spotify";
            if (packageId.equals("com.google.android.youtube")) return "YouTube";
            if (packageId.equals("com.google.android.apps.youtube.music")) return "YouTube Music";
            if (packageId.equals("com.zhiliaoapp.musically") || packageId.equals("com.ss.android.ugc.trill")) return "TikTok";
            return packageId;
        }
    }

    private boolean hasUsageAccess() {
        AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        return ops != null && ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private boolean hasMediaAccess() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        return manager != null && manager.isNotificationListenerAccessGranted(new ComponentName(this, MediaAccessService.class));
    }

    private void toggleMedia(MediaController controller) {
        try {
            PlaybackState state = controller.getPlaybackState();
            if (state != null && state.getState() == PlaybackState.STATE_PLAYING)
                controller.getTransportControls().pause();
            else controller.getTransportControls().play();
            handler.postDelayed(this::refreshAppList, 600);
        } catch (Exception e) { toast("Diese App erlaubt keine externe Wiedergabesteuerung."); }
    }

    private void requestRefresh() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLUETOOTH);
            return;
        }
        refreshDevices();
    }

    private boolean bluetoothGranted() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothProfiles() {
        if (profileRequestsStarted || !bluetoothGranted() || bluetoothAdapter == null) return;
        profileRequestsStarted = true;
        try {
            boolean headsetRequested = bluetoothAdapter.getProfileProxy(getApplicationContext(), profileListener, BluetoothProfile.HEADSET);
            boolean musicRequested = bluetoothAdapter.getProfileProxy(getApplicationContext(), profileListener, BluetoothProfile.A2DP);
            profileRequestsStarted = headsetRequested || musicRequested;
        } catch (SecurityException ignored) { profileRequestsStarted = false; }
    }

    private Set<String> connectedAddresses(BluetoothProfile proxy) {
        Set<String> addresses = new HashSet<>();
        if (proxy == null || !bluetoothGranted()) return addresses;
        try {
            for (BluetoothDevice device : proxy.getConnectedDevices()) addresses.add(device.getAddress());
        } catch (SecurityException ignored) {}
        return addresses;
    }

    private void refreshDevices() {
        if (deviceState == null || inputSelector == null) return;
        if (!bluetoothGranted()) {
            deviceState.setText("Zum Erkennen der Bluetooth-Geräte auf »GERÄTE PRÜFEN« tippen und die Berechtigung erlauben.");
            if (micDetectionSummary != null) micDetectionSummary.setText("Mikrofonstatus: Bluetooth-Berechtigung fehlt");
            setSpinnerPlaceholder("Berechtigung fehlt");
            return;
        }
        requestBluetoothProfiles();
        try {
            AudioDeviceInfo[] outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            AudioDeviceInfo[] inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS);
            List<String> descriptions = new ArrayList<>();
            List<String> entries = new ArrayList<>();
            int previouslySelectedId = -1;
            int oldSelection = inputSelector.getSelectedItemPosition();
            if (oldSelection >= 0 && oldSelection < inputDevices.size())
                previouslySelectedId = inputDevices.get(oldSelection).getId();
            inputDevices.clear();
            int btInputs = 0;
            for (AudioDeviceInfo input : inputs) {
                if (isBluetooth(input)) {
                    btInputs++;
                    descriptions.add("🎙  MIKROFON-EINGANG ERKANNT: " + safeName(input) + " (" + typeName(input) + ")");
                }
                if (input.isSource()) {
                    inputDevices.add(input);
                    entries.add(safeName(input) + " · " + typeName(input));
                }
            }
            for (AudioDeviceInfo output : outputs) {
                if (isBluetooth(output)) {
                    descriptions.add("🔊  AUDIO-AUSGANG: " + safeName(output) + " (" + typeName(output) + ")");
                }
            }
            Set<String> headset = connectedAddresses(headsetProfile);
            Set<String> a2dp = connectedAddresses(musicProfile);
            if (bluetoothAdapter != null) {
                Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
                if (paired != null) {
                    for (BluetoothDevice device : paired) {
                        String address = device.getAddress();
                        String name = device.getName() == null ? "Bluetooth-Gerät" : device.getName();
                        if (headset.contains(address)) {
                            descriptions.add("🎤  " + name + " · FREISPRECHPROFIL VERBUNDEN: Mikrofon wahrscheinlich, bitte testen");
                        } else if (a2dp.contains(address)) {
                            descriptions.add("🔈  " + name + " · Musik verbunden, kein aktiver Mikrofonanschluss bestätigt");
                        } else {
                            descriptions.add("◌  " + name + " · gekoppelt, nicht als Audio-/Headsetprofil verbunden; Mikrofon unbekannt");
                        }
                    }
                }
            }
            deviceState.setText(descriptions.isEmpty()
                    ? "Noch keine Bluetooth-Audioanschlüsse angezeigt. Erst Box/Headset in Android verbinden."
                    : android.text.TextUtils.join("\n\n", descriptions));
            if (micDetectionSummary != null) {
                micDetectionSummary.setText("Bluetooth-Mikrofon-Eingänge: " + btInputs
                        + "  |  Freisprechprofile verbunden: " + headset.size()
                        + "\nAussage zur echten Mikrofonfunktion nur nach Test sicher.");
            }
            if (entries.isEmpty()) entries.add("Keine Mikrofonquelle verfügbar");
            setSpinnerEntries(entries);
            if (previouslySelectedId != -1) {
                for (int i = 0; i < inputDevices.size(); i++) {
                    if (inputDevices.get(i).getId() == previouslySelectedId) { inputSelector.setSelection(i); break; }
                }
            }
        } catch (SecurityException e) {
            deviceState.setText("Bluetooth-Berechtigung ist zum Auslesen der Geräte erforderlich.");
            setSpinnerPlaceholder("Berechtigung fehlt");
        } catch (Exception e) {
            deviceState.setText("Geräteübersicht momentan nicht verfügbar: " + e.getClass().getSimpleName());
        }
    }

    private void setSpinnerPlaceholder(String placeholder) {
        List<String> lines = new ArrayList<>();
        lines.add(placeholder);
        setSpinnerEntries(lines);
    }
    private void setSpinnerEntries(List<String> lines) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lines) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                if (view instanceof TextView) ((TextView) view).setTextColor(TEXT);
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(TEXT);
                    view.setBackgroundColor(CARD);
                }
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        inputSelector.setAdapter(adapter);
    }
    private boolean isBluetooth(AudioDeviceInfo device) {
        switch (device.getType()) {
            case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP:
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:
            case AudioDeviceInfo.TYPE_BLE_HEADSET:
            case AudioDeviceInfo.TYPE_BLE_SPEAKER:
            case AudioDeviceInfo.TYPE_BLE_BROADCAST:
                return true;
            default: return false;
        }
    }
    private String typeName(AudioDeviceInfo device) {
        switch (device.getType()) {
            case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP: return "Bluetooth-Musik";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth-Headset";
            case AudioDeviceInfo.TYPE_BLE_HEADSET: return "Bluetooth LE-Headset";
            case AudioDeviceInfo.TYPE_BLE_SPEAKER: return "Bluetooth LE-Box";
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: return "Handy-Mikrofon";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "Kabel-Headset";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB-Headset";
            default: return "Typ " + device.getType();
        }
    }
    private String safeName(AudioDeviceInfo device) {
        CharSequence name = device.getProductName();
        if (name == null || name.length() == 0) return "Unbenanntes Gerät";
        return name.toString();
    }

    private void toggleMic() {
        if (recording) { stopMicrophone(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
            return;
        }
        startMicrophone();
    }

    private void startMicrophone() {
        if (recording) return;
        final int sampleRate = 16000;
        final int channel = AudioFormat.CHANNEL_IN_MONO;
        final int encoding = AudioFormat.ENCODING_PCM_16BIT;
        int bufferMin = AudioRecord.getMinBufferSize(sampleRate, channel, encoding);
        if (bufferMin <= 0) { micState.setText("Audioaufnahme auf diesem Gerät nicht verfügbar."); return; }
        int bufferBytes = Math.max(bufferMin * 2, 4096);
        AudioRecord candidate = null;
        try {
            candidate = new AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(new AudioFormat.Builder().setEncoding(encoding).setSampleRate(sampleRate).setChannelMask(channel).build())
                .setBufferSizeInBytes(bufferBytes)
                .build();
            if (candidate.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Mikrofon nicht bereit");
            int which = inputSelector.getSelectedItemPosition();
            boolean requestedDevice = false;
            if (which >= 0 && which < inputDevices.size()) {
                requestedDevice = candidate.setPreferredDevice(inputDevices.get(which));
            }
            candidate.startRecording();
            if (candidate.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Aufnahme nicht gestartet");
            recorder = candidate;
            recording = true;
            micButton.setText("MIKROFONTEST STOPPEN");
            String routing = requestedDevice ? "Ausgewählte Quelle angefragt; Android kann davon abweichen." : "Android wählt die Mikrofonquelle.";
            micState.setText("Test läuft. " + routing);
            final AudioRecord active = candidate;
            recorderThread = new Thread(() -> {
                short[] samples = new short[1024];
                int counter = 0;
                while (recording) {
                    int num = active.read(samples, 0, samples.length);
                    if (num <= 0) break;
                    double squares = 0;
                    for (int i = 0; i < num; i++) squares += ((double) samples[i]) * samples[i];
                    double rms = Math.sqrt(squares / num) / Short.MAX_VALUE;
                    int level = Math.min(100, (int) Math.round(rms * 650));
                    if ((counter++ % 3) == 0) {
                        handler.post(() -> {
                            if (!recording) return;
                            microphoneMeter.setProgress(level);
                            if (micTrack != null) micTrack.setLevel(level);
                            AudioDeviceInfo routed = active.getRoutedDevice();
                            if (routed != null) micState.setText("Aktueller Mikrofonweg: " + safeName(routed) + " · Pegel " + level + "%");
                        });
                    }
                }
                handler.post(() -> { if (recording) stopMicrophone(); });
            }, "WolfMicMeter");
            recorderThread.start();
        } catch (Exception e) {
            if (candidate != null) try { candidate.release(); } catch (Exception ignored) {}
            recorder = null;
            recording = false;
            micState.setText("Mikrofontest fehlgeschlagen: " + e.getClass().getSimpleName());
            micButton.setText("MIKROFON TESTEN");
        }
    }

    private void stopMicrophone() {
        if (!recording && recorder == null) return;
        recording = false;
        AudioRecord old = recorder;
        recorder = null;
        if (old != null) {
            try { old.stop(); } catch (Exception ignored) {}
            // Der Recorder wird nach Beenden des Lesethreads freigegeben.
            Thread closing = new Thread(() -> {
                Thread thread = recorderThread;
                if (thread != null && thread != Thread.currentThread()) {
                    try { thread.join(500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                }
                try { old.release(); } catch (Exception ignored) {}
            }, "WolfMicClose");
            closing.start();
        }
        if (micButton != null) micButton.setText("MIKROFON TESTEN");
        if (micState != null) micState.setText("Mikrofontest aus");
        if (microphoneMeter != null) microphoneMeter.setProgress(0);
        if (micTrack != null) micTrack.setLevel(0);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (grants.length == 0 || grants[0] != PackageManager.PERMISSION_GRANTED) {
            toast("Berechtigung nicht erteilt – die Funktion bleibt ausgeschaltet.");
            return;
        }
        if (code == REQUEST_BLUETOOTH) refreshDevices();
        else if (code == REQUEST_MICROPHONE) startMicrophone();
    }
    @Override protected void onPause() {
        if (loopEffect != null && loopEffect.isChecked()) stopEffect();
        stopMicrophone();
        super.onPause();
    }
    @Override protected void onDestroy() {
        stopEffect();
        stopMicrophone();
        if (audioCallback != null) audioManager.unregisterAudioDeviceCallback(audioCallback);
        if (bluetoothAdapter != null) {
            try {
                if (headsetProfile != null) bluetoothAdapter.closeProfileProxy(BluetoothProfile.HEADSET, headsetProfile);
                if (musicProfile != null) bluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, musicProfile);
            } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    private void openApp(String packageId) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageId);
        if (launch != null) { startActivity(launch); return; }
        toast("App nicht gefunden. Bitte zuerst installieren: " + packageId);
    }
    private void openTiktok() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
        if (launch == null) launch = getPackageManager().getLaunchIntentForPackage("com.ss.android.ugc.trill");
        if (launch != null) startActivity(launch);
        else toast("TikTok nicht gefunden.");
    }
    private void openSoundAssistant() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.samsung.android.soundassistant");
        if (launch != null) { startActivity(launch); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://galaxystore.samsung.com/detail/com.samsung.android.soundassistant"))); }
        catch (ActivityNotFoundException e) { toast("Bitte Sound Assistant im Galaxy Store suchen."); }
    }
    private void openSoundSettings() { launchSettings(Settings.ACTION_SOUND_SETTINGS); }
    private void openBluetoothSettings() { launchSettings(Settings.ACTION_BLUETOOTH_SETTINGS); }
    private void launchSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    /** Fader-Anzeige wie ein Mischpult; nur der Master ist ein echter Lautstärkeregler. */
    private void createMixerBoard() {
        LinearLayout header = card("PROFI-MISCHPULT  ▸  KANÄLE", YELLOW);
        label(header, "Ziehe den MASTER-Regler für die gemeinsame Medienlautstärke. Andere Kanäle zeigen nur diesen Pegel; getrennte App-Fader bietet Android normalen Apps nicht.", 12, SUB);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(true);
        LinearLayout tracks = new LinearLayout(this);
        tracks.setOrientation(LinearLayout.HORIZONTAL);
        tracks.setPadding(dp(2), dp(6), dp(2), dp(12));
        scroll.addView(tracks);
        header.addView(scroll);
        addMixerTrack(tracks, "SPOTIFY", "MUSIK", Color.rgb(43, 220, 128), "com.spotify.music", false, false);
        addMixerTrack(tracks, "YOUTUBE", "VIDEO", Color.rgb(255, 96, 97), "com.google.android.youtube", false, false);
        addMixerTrack(tracks, "YT MUSIC", "MUSIK", Color.rgb(239, 105, 168), "com.google.android.apps.youtube.music", false, false);
        addMixerTrack(tracks, "TIKTOK", "LIVE", CYAN, "com.zhiliaoapp.musically", false, false);
        addMixerTrack(tracks, "MIC", "EINGANG", Color.rgb(166, 227, 89), null, true, false);
        addMixerTrack(tracks, "MASTER", "SYSTEM", YELLOW, null, false, true);
        label(header, "APP-MUTE/Einzellautstärken: soweit verfügbar über Samsung Sound Assistant. Die Mikrofonanzeige ist nur bei laufendem Test ein gemessener Pegel.", 12, SUB);
    }

    private void addMixerTrack(LinearLayout parent, String name, String subtitle, int color,
                               String packageName, boolean microphone, boolean master) {
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setGravity(Gravity.CENTER_HORIZONTAL);
        strip.setPadding(dp(5), dp(12), dp(5), dp(11));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(31, 44, 62));
        background.setCornerRadius(dp(11));
        background.setStroke(dp(1), Color.rgb(64, 82, 102));
        strip.setBackground(background);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(113), -2);
        lp.rightMargin = dp(6);
        parent.addView(strip, lp);
        TextView chName = text(name, 13, color, true);
        chName.setGravity(Gravity.CENTER);
        strip.addView(chName, new LinearLayout.LayoutParams(-1, dp(24)));
        TextView category = text(subtitle, 10, SUB, false);
        category.setGravity(Gravity.CENTER);
        strip.addView(category);
        View led = new View(this);
        GradientDrawable ledBg = new GradientDrawable();
        ledBg.setColor(color);
        ledBg.setCornerRadius(dp(3));
        led.setBackground(ledBg);
        LinearLayout.LayoutParams ledLp = new LinearLayout.LayoutParams(dp(61), dp(5));
        ledLp.topMargin = dp(11);
        strip.addView(led, ledLp);
        LevelTrack fader = new LevelTrack(color, master);
        LinearLayout.LayoutParams faderLp = new LinearLayout.LayoutParams(dp(76), dp(160));
        faderLp.topMargin = dp(13);
        strip.addView(fader, faderLp);
        if (microphone) micTrack = fader;
        else {
            musicTracks.add(fader);
            int vol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            fader.setLevel(Math.round(vol * 100f / Math.max(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC))));
        }
        TextView caption = text(microphone ? "MIC-TEST" : (master ? "LAUTSTÄRKE" : "MASTER-PEGEL"), 9, SUB, true);
        caption.setGravity(Gravity.CENTER);
        strip.addView(caption, new LinearLayout.LayoutParams(-1, dp(31)));
        Button action = button(microphone ? "TEST" : master ? "MUTE" : "ÖFFNEN", color,
                () -> {
                    if (microphone) toggleMic();
                    else if (master) toggleGlobalMute();
                    else openApp(packageName);
                });
        action.setTextSize(11);
        strip.addView(action, new LinearLayout.LayoutParams(-1, dp(36)));
        if (packageName != null && !name.equals("TIKTOK")) {
            Button play = button("PLAY/PAUSE", Color.rgb(148, 171, 187), () -> togglePlaybackOf(packageName));
            play.setTextSize(9);
            LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(-1, dp(32));
            pb.topMargin = dp(5);
            strip.addView(play, pb);
        } else {
            TextView spacer = text(master ? "Alle Apps" : microphone ? "Lokaler Test" : "Live-App", 10, SUB, false);
            spacer.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(-1, dp(37));
            pb.topMargin = dp(5);
            strip.addView(spacer, pb);
        }
    }

    private void togglePlaybackOf(String packageName) {
        if (!hasMediaAccess()) {
            toast("Bitte zuerst MEDIENZUGRIFF aktivieren. Play/Pause steuert nur angebotene Mediensitzungen.");
            return;
        }
        try {
            MediaSessionManager manager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            for (MediaController controller : manager.getActiveSessions(new ComponentName(this, MediaAccessService.class))) {
                if (packageName.equals(controller.getPackageName())) { toggleMedia(controller); return; }
            }
        } catch (Exception ignored) {}
        toast("Keine aktive Mediensitzung für " + appName(packageName) + " gefunden.");
    }

    private void toggleGlobalMute() {
        int old = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (old > 0) previousMediaVolume = old;
        int next = old == 0 ? Math.min(Math.max(1, previousMediaVolume), audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) : 0;
        try { audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0); }
        catch (Exception e) { toast("Stummschalten nicht erlaubt."); }
        if (musicSlider != null) musicSlider.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        updateMusicLevel();
    }

    private void setGlobalMediaVolume(int percent) {
        int max = Math.max(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int next = Math.round(percent * max / 100f);
        try { audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0); }
        catch (Exception e) { toast("Medienlautstärke nicht änderbar."); }
        if (musicSlider != null) musicSlider.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        updateMusicLevel();
    }

    private final class LevelTrack extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int color;
        private final boolean editable;
        private int level = 0;
        LevelTrack(int color, boolean editable) {
            super(MainActivity.this);
            this.color = color; this.editable = editable;
            setContentDescription(editable ? "Master-Lautstärkeregler" : "Pegelanzeige");
        }
        void setLevel(int level) { this.level = Math.min(100, Math.max(0, level)); invalidate(); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float top = dp(11);
            float bottom = getHeight() - dp(11);
            float height = bottom - top;
            paint.setColor(Color.rgb(6, 14, 23));
            canvas.drawRoundRect(new RectF(cx - dp(7), top, cx + dp(7), bottom), dp(6), dp(6), paint);
            for (int i = 0; i <= 10; i++) {
                float y = top + i * height / 10f;
                paint.setColor(i % 2 == 0 ? Color.rgb(140, 164, 179) : Color.rgb(70, 91, 112));
                canvas.drawRect(cx - dp(27), y, cx - dp(16), y + dp(1), paint);
                canvas.drawRect(cx + dp(16), y, cx + dp(27), y + dp(1), paint);
            }
            float y = bottom - (level / 100f) * height;
            paint.setColor(color);
            canvas.drawRoundRect(new RectF(cx - dp(5), y, cx + dp(5), bottom), dp(5), dp(5), paint);
            paint.setColor(Color.rgb(222, 231, 235));
            canvas.drawRoundRect(new RectF(cx - dp(19), y - dp(8), cx + dp(19), y + dp(8)), dp(3), dp(3), paint);
            paint.setColor(Color.rgb(80, 105, 130));
            canvas.drawRect(cx - dp(15), y, cx + dp(15), y + dp(2), paint);
        }
        @Override public boolean onTouchEvent(MotionEvent event) {
            if (!editable) return false;
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                float top = dp(11);
                float usable = Math.max(1, getHeight() - dp(22));
                int p = Math.round((1f - ((event.getY() - top) / usable)) * 100);
                setLevel(p);
                setGlobalMediaVolume(Math.max(0, Math.min(100, p)));
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP;
        }
    }

    private LinearLayout card(String header, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setPadding(dp(15), dp(15), dp(15), dp(16));
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable background = new GradientDrawable();
        background.setColor(CARD);
        background.setCornerRadius(dp(17));
        background.setStroke(dp(1), Color.rgb(47, 67, 89));
        card.setBackground(background);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));
        card.addView(text(header, 16, accent, true));
        space(card, 8);
        return card;
    }
    private void rowButtons(LinearLayout parent, String left, Runnable leftCall, String right, Runnable rightCall) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, 0);
        Button b1 = button(left, YELLOW, leftCall);
        Button b2 = button(right, CYAN, rightCall);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(49), 1);
        lp1.rightMargin = dp(5);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(49), 1);
        lp2.leftMargin = dp(5);
        row.addView(b1, lp1); row.addView(b2, lp2);
        parent.addView(row);
    }
    private Button button(String name, int accent, Runnable action) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(name);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(BG);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accent);
        bg.setCornerRadius(dp(10));
        b.setBackground(bg);
        b.setOnClickListener(view -> action.run());
        return b;
    }
    private void label(LinearLayout parent, String msg, int size, int color) {
        TextView t = text(msg, size, color, false);
        parent.addView(t);
        space(parent, 4);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private void space(LinearLayout parent, int dps) {
        View spacer = new View(this);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(dps)));
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
}
