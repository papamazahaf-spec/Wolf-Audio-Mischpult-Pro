package de.wolf.btaudioduo;

import android.service.notification.NotificationListenerService;

/**
 * System-authorized notification listener to request access to active MediaSession controllers.
 * Does not read, save, transmit, or display notification contents.
 */
public class MediaAccessService extends NotificationListenerService {
}